<div id="footer-wrap">
	<p id="legal">Plovdiv Online Book Store 2014</p>
	</div>